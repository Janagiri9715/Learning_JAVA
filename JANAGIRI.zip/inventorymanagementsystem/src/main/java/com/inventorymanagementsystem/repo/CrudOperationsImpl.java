package com.inventorymanagementsystem.repo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.inventorymanagementsystem.product.Product;

public class CrudOperationsImpl implements CrudOperations {

	public List<Product> products = new ArrayList<>();

	private CrudOperationsImpl() {

	}

	private static CrudOperationsImpl crudOperationsImpl;

	public static CrudOperationsImpl getcrudOperationsImpl() {
		if (crudOperationsImpl == null) {
			crudOperationsImpl = new CrudOperationsImpl();
			return crudOperationsImpl;
		}
		return crudOperationsImpl;
	}

	@Override
	public void add(Product product) {
		// TODO Auto-generated method stub
		products.add(product);
	}

	@Override
	public Product getByProductId(String id) {
		// TODO Auto-generated method stub

		for (Product product : products) {
			if (product.getProductID().equals(id)) {
				return product;
			}
		}
		return null;
	}

	@Override
	public List<Product> getByProducts() {
		// TODO Auto-generated method stub
		return products;
	}

	@Override
	public Product update(String name, String id) {
		// TODO Auto-generated method stub

		for (Product product1 : products) {
			if (product1.getProductID().equalsIgnoreCase(id)) {

				product1.setName("Laptop");
				return product1;
			}
		}
		return null;
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub
		Iterator<Product> iterator = products.iterator();

		while (iterator.hasNext()) {
			Product product = iterator.next();

			if (product.getProductID().equals(id)) {
				iterator.remove();
			}
		}

	}

}
