package com.inventorymanagementsystem.product;

import java.util.UUID;

public class Product {

	private String productID;
	private String name;
	private String description;
	private double price;
	private int quantity;

	public Product(String name, String description, double price, int quantity) {
		super();
		this.productID = UUID.randomUUID().toString();
		setName(name);
		setDescription(description);
		setPrice(price);
		setQuantity(quantity);
	}

	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {

		return price;

	}

	public void setPrice(double price) {
		if (price >= 0) {
			this.price = price;
		} else {
			throw new IllegalArgumentException("Price cannot be negative");
		}

	}

	public int getQuantity() {
		return quantity;

	}

	public void setQuantity(int quantity) {
		if (quantity >= 0) {
			this.quantity = quantity;
		} else {
			throw new IllegalArgumentException("Quantity cannot be negative");
		}
	}

	@Override
	public String toString() {
		return "Product [productID=" + productID + ", name=" + name + ", description=" + description + ", price=" + price
				+ ", quantity=" + quantity + "]";
	}


}
