package com.inventorymanagementsystem.product;

import java.util.List;

import com.inventorymanagementsystem.service.InventoryService;
import com.inventorymanagementsystem.service.InventoryServiceImpl;

public class App {

	public static void main(String[] args) {

		InventoryService inventoryService = InventoryServiceImpl.getinventoryServiceImpl();
		Product product = new Product("Water Bottle", "Good to use", 100, 1);

		usingCase("Add", product, inventoryService);
		usingCase("GetByProducts", product, inventoryService);
		usingCase("GetByProductId", product, inventoryService);
		usingCase("Update", product, inventoryService);
		usingCase("Delete", product, inventoryService);

	}

	public static void usingCase(String ss, Product p, InventoryService inventoryService) {

		switch (ss) {
			case "Add":
				inventoryService.add(p);
				break;
			case "GetByProducts":
				List<Product> productbyUser = inventoryService.getByProducts();
				if (productbyUser != null && !productbyUser.isEmpty()) {
					System.out.println("productbyUser :: " + productbyUser);
				}
				break;
			case "GetByProductId":
				Product productbyId = inventoryService.getByProductId(p.getProductID());
				if (productbyId != null) {
					System.out.println("productbyId :: " + productbyId);
				}
				break;
			case "Update":
				Product productUpdate = inventoryService.update(p.getName(), p.getProductID());
				System.out.println("productUpdate :: " + productUpdate);
				break;
			case "Delete":
				inventoryService.delete(p.getProductID());
				break;
			default:
				System.out.println("Invalid operation");
		}
	}

}
