package com.inventorymanagementsystem.service;

import java.util.List;

import com.inventorymanagementsystem.product.Product;
import com.inventorymanagementsystem.repo.CrudOperations;
import com.inventorymanagementsystem.repo.CrudOperationsImpl;


public class InventoryServiceImpl implements InventoryService {

	public CrudOperations crudOperations = CrudOperationsImpl.getcrudOperationsImpl();

	private static InventoryServiceImpl inventoryServiceImpl;

	private InventoryServiceImpl() {
		super();
	}

	public static InventoryServiceImpl getinventoryServiceImpl() {
		if (inventoryServiceImpl == null) {
			inventoryServiceImpl = new InventoryServiceImpl();
		}
		return inventoryServiceImpl;
	}

	@Override
	public void add(Product product) {
		// TODO Auto-generated method stub
		crudOperations.add(product);
	}

	@Override
	public Product getByProductId(String id) {
		// TODO Auto-generated method stub
		return crudOperations.getByProductId(id);
	}

	@Override
	public List<Product> getByProducts() {
		// TODO Auto-generated method stub
		return crudOperations.getByProducts();
	}

	@Override
	public Product update(String name, String id) {
		// TODO Auto-generated method stub
		return crudOperations.update(name, id);
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub
		crudOperations.delete(id);
	}

}
