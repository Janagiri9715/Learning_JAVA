package com.inventorymanagementsystem.service;

import java.util.List;

import com.inventorymanagementsystem.product.Product;

public interface InventoryService {

	void add(Product product);

	Product getByProductId(String id);

	List<Product> getByProducts();

	Product update(String name, String id);

	void delete(String id);

}
